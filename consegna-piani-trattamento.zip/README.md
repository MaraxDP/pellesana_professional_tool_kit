# Piani di trattamento

Pacchetto autonomo per sviluppare un?app dedicata ai piani per problematica.
Contiene 9 piani, 8 problematiche e 88 sedute complessive.

## File

- `piani-trattamento.json`: dati strutturati UTF-8, importabili senza dipendenze.
- `PIANI.md`: versione leggibile degli stessi piani.

## Struttura dei dati

- `problematiche`: identificativi e nomi delle problematiche, nell?ordine originale.
- `piani`: identificativo, nome, categorie, obiettivo, condizioni iniziali, durata, note, cicli e riferimenti home care di ogni piano.
- `cicli`: titolo, periodo e sedute nell?ordine originale.
- `sedute`: etichetta, fase e array degli attivi.
- `legendaAttivi`: nomi delle sigle utilizzate e identificativi dei prodotti richiamati nei piani; non contiene schede prodotto.
- `riferimentiHomeCare`: esclusivamente identificativo e nome dei prodotti gi? associati ai piani.

## Interpretazione fedele della fonte

I contenuti dei piani sono riprodotti senza modifiche dai dati della piattaforma. Le sedute generate dal codice originale sono espanse in JSON. Conservare l?ordine di cicli, sedute e attivi.

Le stringhe con barra (esempio `AI3 / MIX`) e le ripetizioni (esempio `["NAD", "NAD"]`) sono mantenute esattamente come nella fonte: non trasformarle automaticamente in dosaggi o istruzioni di miscelazione. Fare riferimento alle note di ogni piano per le alternative.

Le fasi sono riportate con le sigle originali. Non sono state aggiunte tempistiche, dosi o procedure assenti dal singolo piano. Un array `homeCareIds` vuoto indica che il piano non specifica prodotti domiciliari; non equivale a una controindicazione.

La denominazione AAP ? conservata come nella legenda originale: ?Antiaging Peeling Plus?, con identificativo `antiaging-peeling-cocktail`.

Il riferimento al PDF nelle note di Anti Hair Loss ? testo originale del piano; nessun PDF ? incluso nel pacchetto.

## Perimetro della consegna

Sono presenti soltanto i piani e i riferimenti minimi necessari a leggerli. Sono esclusi cataloghi e schede prodotto, procedure separate, formazione, marketing, prezzi, risultati, immagini, dati clienti, codice della piattaforma e cronologia Git originale.

La cartella pu? essere utilizzata come repository indipendente. Lo ZIP contiene esclusivamente i tre file sopra indicati, senza metadati Git. Nessun servizio esterno ? necessario per leggere i contenuti.
