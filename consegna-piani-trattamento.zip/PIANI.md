# Piani di trattamento

Trascrizione dei piani presenti nella piattaforma al momento dell?estrazione.

## Protocollo Prevenzione

**Problematica:** Prevenzione & Skin Longevity

**Obiettivo:** Preservare nel tempo vitalità, idratazione e qualità cutanea, sostenendo precocemente i naturali processi di rinnovamento.

**Condizioni iniziali:** Pelle in buono stato generale, con primi segnali di disidratazione, stanchezza o perdita di luminosità e necessità di prevenzione evolutiva.

**Durata:** 8 mesi + mantenimento domiciliare

### Preparazione rivitalizzante

Primi 2 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 1 | B.R. | EXO; ADRN |
| Seduta 2 | B.R. | EXO; ADRN |
| Seduta 3 | B.R. | NAD; NAD |
| Seduta 4 | B.R. | NAD; NAD |

### Ricostituente

Secondi 6 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 5 | IDR | AI3 / MIX |
| Seduta 6 | IDR | AI3 / MIX |
| Seduta 7 | VIT | POLI |
| Seduta 8 | VIT | POLI |
| Seduta 9 | PRO | GF |
| Seduta 10 | PRO | GF |

**Legenda degli attivi:**

- EXO: Exobio Plus
- ADRN: ADRN Plus
- NAD: NAD Plus Glow
- AI3: Acido Ialuronico 3%
- MIX: Acido Ialuronico 1% + DMAE 1% + Silicio Organico 0,5%
- POLI: Polivitaminico
- GF: Growth Factor GF#1

**Home care associato:**

- Exobio Facial Cream
- Exobio Eye Contour
- Exobio Facial Serum
- ADRN Pro Facial Cream
- ADRN Pro Eye Contour
- ADRN Pro Facial Serum

**Note:** La scelta tra AI3 e MIX viene definita dalla professionista in base alla valutazione cutanea.

## Protocollo Lip Volume & Eye Care

**Problematica:** Prevenzione & Skin Longevity

**Obiettivo:** Idratare e valorizzare l'area labbra e migliorare l'aspetto del contorno occhi con un percorso mirato e progressivo.

**Condizioni iniziali:** Labbra disidratate o poco definite e contorno occhi segnato da secchezza, stanchezza, borse o occhiaie.

**Durata:** 2 mesi

### Nano needling

Cadenza settimanale in 2 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 1 | LABBRA / C. OCCHI | AI3; FE |
| Seduta 2 | LABBRA / C. OCCHI | AI3; FE |
| Seduta 3 | LABBRA / C. OCCHI | AI3; FE |
| Seduta 4 | LABBRA / C. OCCHI | AI3; FE |
| Seduta 5 | LABBRA / C. OCCHI | AI3; FE |
| Seduta 6 | LABBRA / C. OCCHI | AI3; FE |
| Seduta 7 | LABBRA / C. OCCHI | AI3; FE |
| Seduta 8 | LABBRA / C. OCCHI | AI3; FE |

**Legenda degli attivi:**

- AI3: Acido Ialuronico 3%
- FE: Flash Eye

**Home care associato:**

Non specificato nei dati del piano.

**Note:** Trattamenti di nano needling effettuati con cadenza settimanale.

## Protocollo Antiaging

**Problematica:** Invecchiamento Cutaneo Avanzato

**Obiettivo:** Intervenire sui segni avanzati dell'invecchiamento sostenendo rivitalizzazione, idratazione, compattezza e qualità della texture.

**Condizioni iniziali:** Pelle matura con rughe visibili, perdita di densità, disidratazione e riduzione della luminosità.

**Durata:** 8 mesi

### Preparazione rivitalizzante

Primi 2 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 1 | B.R. / ACIDI | EXO / NAD; AAP |
| Seduta 2 | B.R. / ACIDI | EXO / NAD; AAP |
| Seduta 3 | B.R. / ACIDI | EXO / NAD; AAP |
| Seduta 4 | B.R. / ACIDI | EXO / NAD; AAP |

### Mantenimento ricostituzione

Secondi 6 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 5 | IDR | AI3 / SO |
| Seduta 6 | IDR | AI3 / SO |
| Seduta 7 | VIT | VIT C |
| Seduta 8 | VIT | VIT C |
| Seduta 9 | PRO | BTX |
| Seduta 10 | PRO | BTX |

**Legenda degli attivi:**

- EXO: Exobio Plus
- NAD: NAD Plus Glow
- AAP: Antiaging Peeling Plus
- AI3: Acido Ialuronico 3%
- SO: Silicio Organico
- VIT C: Vitamina C 10%
- BTX: Botxlike Argireline 10%

**Home care associato:**

Non specificato nei dati del piano.

**Note:** Le alternative indicate con la barra devono essere selezionate secondo la valutazione professionale.

## Protocollo Lifting & Volume

**Problematica:** Perdita di Tono e Compattezza

**Obiettivo:** Migliorare tono, compattezza e percezione dei volumi attraverso una progressione rivitalizzante e ricostituente.

**Condizioni iniziali:** Rilassamento cutaneo, perdita di compattezza e volumi meno definiti su viso e collo.

**Durata:** 8 mesi

### Preparazione rivitalizzante

Primi 2 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 1 | B.R. | ADRN |
| Seduta 2 | B.R. | ADRN |
| Seduta 3 | B.R. | ADRN |
| Seduta 4 | B.R. | ADRN |

### Mantenimento ricostituzione

Secondi 6 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 5 | IDR | AI3 / SO |
| Seduta 6 | IDR | AI3 / SO |
| Seduta 7 | VIT | POLI |
| Seduta 8 | VIT | POLI |
| Seduta 9 | PRO | BTX |
| Seduta 10 | PRO | BTX |

**Legenda degli attivi:**

- ADRN: ADRN Plus
- AI3: Acido Ialuronico 3%
- SO: Silicio Organico
- POLI: Polivitaminico
- BTX: Botxlike Argireline 10%

**Home care associato:**

- ADRN Pro Facial Cream
- ADRN Pro Eye Contour
- ADRN Pro Facial Serum

**Note:** La scelta tra AI3 e SO viene definita dalla professionista in base alla condizione cutanea.

## Protocollo Depigmentante & Illuminante

**Problematica:** Discromie Cutanee e Colorito Spento

**Obiettivo:** Uniformare progressivamente l'incarnato e sostenere luminosità e qualità cutanea nel trattamento professionale delle discromie.

**Condizioni iniziali:** Macchie, tono disomogeneo, colorito spento o iperpigmentazione visibile.

**Durata:** 8 mesi

### Preparazione rivitalizzante

Primi 2 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 1 | B.R. / ACIDI | EXO / NAD; DPP / TRAN |
| Seduta 2 | B.R. / ACIDI | EXO / NAD; DPP / TRAN |
| Seduta 3 | B.R. / ACIDI | EXO / NAD; DPP / TRAN |
| Seduta 4 | B.R. / ACIDI | EXO / NAD; DPP / TRAN |

### Mantenimento ricostituzione

Secondi 6 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 5 | IDR | AI3; BRC |
| Seduta 6 | IDR | AI3; BRC |
| Seduta 7 | VIT | VIT C; BRC |
| Seduta 8 | VIT | VIT C; BRC |
| Seduta 9 | PRO | GF; BRC |
| Seduta 10 | PRO | GF; BRC |

**Legenda degli attivi:**

- EXO: Exobio Plus
- NAD: NAD Plus Glow
- DPP: Depigmenting Peeling Plus
- TRAN: Tranexamic Acid
- AI3: Acido Ialuronico 3%
- BRC: Brightening Cocktail
- VIT C: Vitamina C 10%
- GF: Growth Factor GF#1

**Home care associato:**

Non specificato nei dati del piano.

**Note:** Le alternative EXO/NAD e DPP/TRAN devono essere selezionate secondo la valutazione professionale.

## Protocollo Skin Repair

**Problematica:** Esiti Post-Acne e Irregolarità della Texture

**Obiettivo:** Favorire il miglioramento progressivo della texture della pelle danneggiata dagli esiti post-acne.

**Condizioni iniziali:** Esiti post-acne, irregolarità superficiali e texture disomogenea.

**Durata:** 8 mesi

### Preparazione rivitalizzante

Primi 2 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 1 | B.R. / ACIDI | ADRN; TRAN |
| Seduta 2 | B.R. / ACIDI | ADRN; TRAN |
| Seduta 3 | B.R. / ACIDI | ADRN; TRAN |
| Seduta 4 | B.R. / ACIDI | ADRN; TRAN |

### Mantenimento ricostituzione

Secondi 6 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 5 | IDR | AI3 / MIX |
| Seduta 6 | IDR | AI3 / MIX |
| Seduta 7 | VIT | VIT C |
| Seduta 8 | VIT | VIT C |
| Seduta 9 | PRO | GF |
| Seduta 10 | PRO | GF |

**Legenda degli attivi:**

- ADRN: ADRN Plus
- TRAN: Tranexamic Acid
- AI3: Acido Ialuronico 3%
- MIX: Acido Ialuronico 1% + DMAE 1% + Silicio Organico 0,5%
- VIT C: Vitamina C 10%
- GF: Growth Factor GF#1

**Home care associato:**

- ADRN Pro Facial Cream
- ADRN Pro Eye Contour
- ADRN Pro Facial Serum

**Note:** La scelta tra AI3 e MIX viene definita dalla professionista in base alla valutazione cutanea.

## Protocollo Pelle Sensibile

**Problematica:** Pelle Sensibile

**Obiettivo:** Sostenere comfort, equilibrio e qualità della pelle rispettandone la particolare reattività.

**Condizioni iniziali:** Pelle fragile, reattiva o soggetta a rossore e sensazioni di discomfort.

**Durata:** 8 mesi

### Preparazione rivitalizzante

Primi 2 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 1 | B.R. | ADRN |
| Seduta 2 | B.R. | ADRN |
| Seduta 3 | B.R. | ADRN |
| Seduta 4 | B.R. | ADRN |

### Mantenimento ricostituzione

Secondi 6 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 5 | IDR | AI3 / MIX |
| Seduta 6 | IDR | AI3 / MIX |
| Seduta 7 | VIT | POLI |
| Seduta 8 | VIT | POLI |
| Seduta 9 | PRO | GF |
| Seduta 10 | PRO | GF |

**Legenda degli attivi:**

- ADRN: ADRN Plus
- AI3: Acido Ialuronico 3%
- MIX: Acido Ialuronico 1% + DMAE 1% + Silicio Organico 0,5%
- POLI: Polivitaminico
- GF: Growth Factor GF#1

**Home care associato:**

- ADRN Pro Facial Cream
- ADRN Pro Eye Contour
- ADRN Pro Facial Serum

**Note:** La scelta tra AI3 e MIX viene definita dalla professionista in base alla valutazione cutanea.

## Protocollo Sebo Balance

**Problematica:** Eccesso di Sebo e Pelle a Tendenza Acneica

**Obiettivo:** Riequilibrare l'eccesso di sebo e migliorare progressivamente l'aspetto delle imperfezioni.

**Condizioni iniziali:** Pelle lucida, impura, con pori visibili e tendenza acneica.

**Durata:** 8 mesi

### Preparazione rivitalizzante

Primi 2 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 1 | B.R. / ACIDI | EXO; OSPP |
| Seduta 2 | B.R. / ACIDI | EXO; OSPP |
| Seduta 3 | B.R. / ACIDI | EXO; OSPP |
| Seduta 4 | B.R. / ACIDI | EXO; OSPP |

### Mantenimento ricostituzione

Secondi 6 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 5 | IDR | AI3 |
| Seduta 6 | IDR | AI3 |
| Seduta 7 | VIT | POLI |
| Seduta 8 | VIT | POLI |
| Seduta 9 | PRO | GF |
| Seduta 10 | PRO | GF |

**Legenda degli attivi:**

- EXO: Exobio Plus
- OSPP: Oily Skin Peeling Plus
- AI3: Acido Ialuronico 3%
- POLI: Polivitaminico
- GF: Growth Factor GF#1

**Home care associato:**

- Exobio Facial Cream
- Exobio Eye Contour
- Exobio Facial Serum

**Note:** L'impiego degli attivi segue la sequenza professionale indicata nel documento ufficiale.

## Protocollo Anti Hair Loss

**Problematica:** Diradamento e Indebolimento dei Capelli

**Obiettivo:** Sostenere vitalità del cuoio capelluto e qualità del capello in presenza di diradamento o indebolimento.

**Condizioni iniziali:** Capelli indeboliti o diradati e cuoio capelluto devitalizzato.

**Durata:** 8 mesi

### Preparazione rivitalizzante

Primi 2 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 1 | B.R. | EXHA |
| Seduta 2 | B.R. | EXHA |
| Seduta 3 | B.R. | EXHA |
| Seduta 4 | B.R. | EXHA |

### Mantenimento ricostituzione

Secondi 6 mesi

| Seduta | Fase | Attivi |
| --- | --- | --- |
| Seduta 5 | IDR | AI3 / MIX |
| Seduta 6 | IDR | AI3 / MIX |
| Seduta 7 | VIT | POLI |
| Seduta 8 | VIT | POLI |
| Seduta 9 | PRO | GF |
| Seduta 10 | PRO | GF |

**Legenda degli attivi:**

- EXHA: ExoHair Plus
- AI3: Acido Ialuronico 3%
- MIX: Acido Ialuronico 1% + DMAE 1% + Silicio Organico 0,5%
- POLI: Polivitaminico
- GF: Growth Factor GF#1

**Home care associato:**

Non specificato nei dati del piano.

**Note:** Il PDF non specifica un Home Care per questo protocollo; la scelta tra AI3 e MIX dipende dalla valutazione professionale.
